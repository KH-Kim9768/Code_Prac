package com.example.realapp;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.Nullable;

public class distance extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.distance);
    }
}
