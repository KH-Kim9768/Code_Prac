package com.example.realapp;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.Nullable;


public class interest extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.interest);
    }
}
