package com.example.realapp;

import com.android.volley.RequestQueue;

public class AppHelper {
    public static RequestQueue requestQueue;
}
